# FotoSploit
    FotoSploit es un exploit que ensambla la foto
    de nuestra víctima en un enlace falso {phishing}
    
    FotoSploit in
    Kali linux [nethunter]
    UserLand
    ubuntu
    parrot
    etc..
#### Usage: https://youtu.be/sH15XKPVToA
# Banner FotoSploit 
![Screenshot_20191202-134419_Termux~01](https://user-images.githubusercontent.com/46208706/69989850-269e8280-150a-11ea-8ebc-7a585e17ade4.jpg)
# Installation 
    pkg update && pkg upgrade -y
    pkg install -y php
    pkg install -y python2
    pkg install -y git
    cd $HOME
    git clone https://github.com/Cesar-Hack-Gray/FotoSploit 
    cd FotoSploit
    ls
    bash install.sh 
    ./FotoSploit 
# Installation FotoSploit premium
    pkg update && pkg upgrade -y
    pkg install -y php
    pkg install -y python2
    pkg install -y git
    CD $HOME
    git clone https://github.com/Cesar-Hack-Gray/FotoSploit 
    cd FotoSploit 
    ls
    bash install.sh --install --premium
    ./FotoSploit [option]
#### Installation FotoSploit premium 
https://youtu.be/3dDCzze600I
    
# Screenhost
![e](https://user-images.githubusercontent.com/46208706/69989984-70876880-150a-11ea-96ef-efe7a91f54f0.jpg)
# Eye!!!
     El link portador por serveo o ngrok les informo que
     en messenger [facebook] no saca la foto de la víctima:(
     el link solo saca la foto en Whatzapp o en telegram u otro chat
     ok!
#### Comunity : https://t.me/CesarGray : https://www.CesarHackGray.com : https://t.me/CesarHackGray
#### Channel  : http://youtube.com/c/CésarHackGray_Y_Miickeyy : https://t.me/CesarHackGrayCanal
.
# Usage
    
      _____________________________________________________________________
                 ___             _,.---,---.,_
                 |           ,;~'             '~;,
                 |         ,;                     ;,
        Frontal  |        ;                        ; ,--- Supraorbital Foramen
         Bone    |       ,'                        /'
                 |      ,;                       /' ;,
                 |      ; ;      .          . <-'  ; |
                 |__   | ;   ______       ______   ;<----- Coronal Suture
                 ___   |  '/~ ~ . ~ ~\'  |
                |      |  ~  ,-~~~^~, | ,~^~~~-,  ~  |
      Maxilla,  |       |   |        }:{        | <------ Orbit
     Nasal and  |       |   l       / | \       !   |
     Zygomatic  |      .~  (__,.-- .^. --.,__)  ~.
       Bones    |      |    ----;' / | \  ;-<--------- Infraorbital Foramen
             |__       \__.       \/^\/       .__
                  ___    V| \                 / |V <--- Mastoid Process
                  |       | |T~\___!___!___/~T| |
                  |       | | IIII_I_I_I_IIII | |
         Mandible |       |  \ III I I I III,/  |
                  |        \    ~~~~~~~~~~
                 |          \   .       . <-x---- Mental Foramen
                  |__          \.    ^    .
                                 ^~~~^~~~^
    _________________________________________________________________            
                    Created by @CesarHackGray
                      Usage: show options

     FotoSploit> show options
     ===============
     Cesar Hack Gray
     ===============
     
     Comandos          descripsion
     
     show options      opciones
     set foto          [option]
     set title url     [Titulo]
     set view          [FACEBOOK][YOUTUBE]
     GO                Comenzar
     run               Comenzar
     exit              Salir
     
     
     set title url Cesar-Hack-Gray (example)
     set foto [youtube] [FreeFire] [PUBG]
     [Anime] [pornografia] [Bokep] [facebook]
     [/sdcard/example.jpg]
     
     
     SET FOTO :
     SET VIEW :
     SET TITLE URL :
     
     
     FotoSploit> set foto /sdcard/foto.jpg
     [+] FOTO => /sdcard/foto.jpg
     FotoSploit> set title url Name-Victim
     [+] Name => Name-Victim
     FotoSploit> set view YOUTUBE
     [+] VISTA => www.youtube.com
     FotoSploit> GO
     [+] Uploading -> /sdcard/foto.jpg...
     [+] Abriendo servidores...
     [+] Abriendo servidor php...
     [+] Abriendo servidor ssh...
     [+] Abriendo servidor ngrok..
     [+] Descargando ngrok full....
     [+] Obteniendo URLs..
     [+] Servicio de ayuda = https://t.me/CesarGray
     [+] Envia ala victima = http://localhost:5756
     [+] Envia ala victima = https://1d16900a.ngrok.io
     [+] Interactuando ala victima...

# Remember that the link just takes the picture in whatzapp or in telegram
 ![Screenshot_20191202-165136_WhatsApp~01](https://user-images.githubusercontent.com/46208706/70001918-26ab7c00-1524-11ea-8b40-1c478ea276ec.jpg)
           
              
              
              
     
 
              
                      
  
 
 

   

   
   
   
   
   
   

   







